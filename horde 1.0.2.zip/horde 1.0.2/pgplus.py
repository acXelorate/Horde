import pygame as pg

class camera:
    def __init__(self,wh,wantedwh):
        self.wh=wh
        self.wantedwh=wantedwh
        self.x=0
        self.y=0
        self.scale=(wh[0]/wantedwh[0],wh[1]/wantedwh[1])
    def get_camrect(self):
        return pg.Rect(self.x,self.y,self.x+self.wh[0],self.y+self.wh[1])

class draw:
    @staticmethod
    def rect(surf,cam,color,_rect:pg.Rect,w=0,gui=True,border_radius=-1):
        global rect
        _rect=_rect.copy()
        _rect=rect.get_smart_rect(_rect.copy(),cam,gui).copy()
        if color == "white":
            pass
        pg.draw.rect(surf,color,_rect,w,border_radius)

    

class rect:
    @staticmethod
    def get_smart_rect(_rect,cam,gui=True):
        _rect=_rect.copy()
        if gui==False:
            _rect.x-=cam.x
            _rect.y-=cam.y

        _rect.x*=cam.scale[0]
        _rect.y*=cam.scale[1]
        _rect.w*=cam.scale[0]
        _rect.h*=cam.scale[1]
        return _rect
    @staticmethod
    def collidepoint(cam,_rect:pg.Rect,x,y,gui=True):
        _rect=rect.get_smart_rect(_rect,cam,gui)
        return _rect.collidepoint(x,y)

    @staticmethod
    def colliderect1(cam,rect1,rect2):
        rect1=rect.get_smart_rect(rect1,cam,False)
        if rect1.colliderect(rect2):
            return True
        return False

    @staticmethod
    def collidelistpoint(cam,rectlist,x,y):
        smartlist=[]
        for _rect in rectlist:
            smartlist.append(rect.get_smart_rect(_rect,cam,False))
        for i,smart in enumerate(smartlist):
            if rect.collidepoint(cam,smart,x,y,False):
                return i
        return -1

    @staticmethod
    def collidelistpoint2(rectlist,x,y):
        for i,rect in enumerate(rectlist):
            if rect.collidepoint(x,y):
                return i
        return -1

def blit(surf1:pg.Surface,cam,surf2:pg.Surface,x,y,gui=True):
    w,h=surf2.get_size()
    w*=cam.scale[0]
    h*=cam.scale[1]
    surf2=pg.transform.scale(surf2,(w,h))
    if not gui:
        x-=cam.x
        y-=cam.y

    x*=cam.scale[0]
    y*=cam.scale[1]

    surf1.blit(surf2,(x,y))
