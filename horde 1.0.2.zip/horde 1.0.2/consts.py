import pygame as pg
import pgplus as pgp
import threading
import random
from copy import copy,deepcopy
from math import sqrt,copysign,floor
import pathfindy as pf

#random.seed(2)

inv=[0,0,0]

darkgray=[100,100,100]

pg.init()
window=pg.display.set_mode((1920,1080),pg.FULLSCREEN)
run=1
room=0
clock=pg.time.Clock()

megafont=pg.font.Font(None,200)
font=pg.font.Font(None,100)
minifont=pg.font.Font(None,50)

rect1=pg.Rect(0,0,500,200)
rect1.center=(960,500)
rect22=pg.Rect(0,0,500,200)
rect22.center=(960,800)

playtxt=font.render("PLAY",True,"black")
playrect=playtxt.get_rect(center=rect1.center)
exittxt=font.render("EXIT",True,"black")
exitrect=playtxt.get_rect(center=rect22.center)
playtxt2=font.render("PLAY",True,(0,200,50))
exittxt2=font.render("EXIT",True,(0,200,50))

introtxt=pg.font.Font("Creepster-Regular.ttf",300).render("HORDE",False,(200,50,0))
introrect=introtxt.get_rect(center=(960,200))

credtxt=minifont.render("by Aleksa Radulovic",False,(0,0,0))
credtxt2=minifont.render("by Aleksa Radulovic",False,(0,100,0))
credrect=credtxt.get_rect(bottom=1080,right=1920)

demomode=0

inv1=pg.Rect(810,950,100,100)
inv2=pg.Rect(910,950,100,100)
inv3=pg.Rect(1010,950,100,100)

pausemenu=0

cam=pgp.camera(window.get_size(),(1920,1080))

invslot=0

obblist=[]
itemlist=[]

gui1=0
gui2=0

craftcategory=None
craftpage=0
craft_global_page=0

obbguirect=pg.Rect(400,0,1120,300)

gui1rect1=pg.Rect(0,50,50,1000)
gui1rect2=pg.Rect(0,50,500,1000)
gui2rect1=pg.Rect(0,50,50,1000)
gui2rect2=pg.Rect(0,50,500,1000)
gui2rect1.right=1920
gui2rect2.right=1920

recipes={
    None:[
        
            [[1,1],[2]],
            [[3,3,1],[4]],
            [[5,1,1],[6]]
            
    ],
    1:[
        
            [[1,3,3],[7]],
            [[5,5,8],[9]],
            [[11,1],[12]],
            [[5,1],[13]],
            [[5],[49]],
            [[5,5],[50]],
            [[3],[48]],
            [[3,3],[51]],
            [[5,11,11],[20]],
            [[52,52],[53]],
            [[5],[54]],
            [[54,53,53],[55]],
            
    ],
    2:[
        [[10],[11]],
         [[14],[15]],
         [[32],[33]]
    ],
    3:[
        [[11,11,1],[17]],
        [[11],[21]],
        [[33],[34]], #
        [[12,34],[59]],
        [[21],[24]],
        [[11,11,1],[19]], #
        [[11],[27]],
        [[21,21],[22]],
        [[28,29],[31]], #
        [[31,31,30],[60]], 
        [[31,30],[61]],
        [[31,30,30],[62]], #
    ]
}
#[[28,29],[31]]
unlockedr={}

crafttxt=font.render("CRAFT",True,"white")


itemsh=pg.image.load("items.png").convert_alpha()
itemsprites=[]
w=itemsh.get_size()[0]
for x in range(0,w,100):
    rect=pg.Rect(x,0,100,100)
    itemsprites.append(itemsh.subsurface(rect))

obbsh=pg.image.load("objects.png").convert_alpha()
obbsprites=[]
w=obbsh.get_size()[0]
for x in range(0,w,100):
    rect=pg.Rect(x,0,100,100)
    obbsprites.append(obbsh.subsurface(rect))

guysh=pg.image.load("guy.png").convert_alpha()
guysprites=[]
w=guysh.get_size()[0]
for x in range(0,w,100):
    rect=pg.Rect(x,0,100,100)
    guysprites.append(guysh.subsurface(rect))

itemmodelsprites={2:[],13:[],7:[],4:[],19:[],17:[],62:[],}

tempsh=pg.image.load("woodenpick.png").convert_alpha()
w=tempsh.get_size()[0]
for x in range(0,w,100):
    rect=pg.Rect(x,0,100,100)
    itemmodelsprites[2].append(tempsh.subsurface(rect))

tempsh=pg.image.load("stonepick.png").convert_alpha()
w=tempsh.get_size()[0]
for x in range(0,w,100):
    rect=pg.Rect(x,0,100,100)
    itemmodelsprites[7].append(tempsh.subsurface(rect))

tempsh=pg.image.load("bat.png").convert_alpha()
w=tempsh.get_size()[0]
for x in range(0,w,100):
    rect=pg.Rect(x,0,100,100)
    itemmodelsprites[13].append(tempsh.subsurface(rect))

tempsh=pg.image.load("ironpick.png").convert_alpha()
w=tempsh.get_size()[0]
for x in range(0,w,100):
    rect=pg.Rect(x,0,100,100)
    itemmodelsprites[17].append(tempsh.subsurface(rect))

tempsh=pg.image.load("ironsword.png").convert_alpha()
w=tempsh.get_size()[0]
for x in range(0,w,100):
    rect=pg.Rect(x,0,100,100)
    itemmodelsprites[19].append(tempsh.subsurface(rect))

tempsh=pg.image.load("obsword.png").convert_alpha()
w=tempsh.get_size()[0]
for x in range(0,w,100):
    rect=pg.Rect(x,0,100,100)
    itemmodelsprites[62].append(tempsh.subsurface(rect))

tempsh=pg.image.load("stoneaxe.png").convert_alpha()
w=tempsh.get_size()[0]
for x in range(0,w,100):
    rect=pg.Rect(x,0,100,100)
    itemmodelsprites[4].append(tempsh.subsurface(rect))
    
mobsh=pg.image.load("mob.png").convert_alpha()
mobsprites=[]
w=mobsh.get_size()[0]
for x in range(0,w,100):
    rect=pg.Rect(x,0,100,100)
    mobsprites.append(mobsh.subsurface(rect))

detailsh=pg.image.load("details.png").convert_alpha()
detailsprites=[]
w=detailsh.get_size()[0]
for x in range(0,w,100):
    rect=pg.Rect(x,0,100,100)
    detailsprites.append(detailsh.subsurface(rect))

details=[]

camrect=cam.get_camrect()

transpsurf=pg.Surface((1920,1080))
transpsurf.fill((0,0,10))
transpsurf.set_alpha(180)

toolcd=0

tileobblist=[]

goo=pg.transform.scale(pg.image.load("goo.png"),(300,300))
gooflip=pg.transform.flip(goo,1,0)
gooflip2=pg.transform.flip(goo,0,1)
gooflip3=pg.transform.flip(goo,1,1)

sprites={}
sprites[24]=pg.image.load("ironhelmet.png").convert_alpha()
sprites[22]=pg.image.load("ironchest.png").convert_alpha()
sprites[60]=pg.image.load("obchest.png").convert_alpha()
sprites[61]=pg.image.load("obhelmet.png").convert_alpha()

tools=[2,4,7,17,27]
build=[6,9,49,48,50,51,20]
hammer=[12,59]
weapons=[13,19,1,62]
backpack=[55]
food=[14,15]
armor=[22,24,60,61]

tooldict={
    2:{
        "cd":15,
        "breaktype":"rock",
        "toolpower":1        
    },
    4:{
        "cd":15,
        "breaktype":"wood",
        "toolpower":1
    },
    7:{
        "cd":15,
        "breaktype":"rock",
        "toolpower":2       
    },
    17:{
        "cd":15,
        "breaktype":"rock",
        "toolpower":3        
    },
    27:{
            "cd":15,
            "breaktype":"bucket",
            "toolpower":1        
        },
}

builddict={
    6:{
        "dict":{
            "drawcolor":"gray",
            "workbench":True,
            "wbtype":1,
            "wbpower":2,
            "rclickBreak":True,
            "blitindex":9,
            "gui":True,
            "upgradeitem":[12,1,1],
            "hpower":1,
            "upgradeblit":17
            }
    },
    9:{
            "dict":{
                "drawcolor":"brown",
                "workbench":True,
                "wbtype":2,
                "wbpower":1,
                "rclickBreak":True,
                "blitindex":10
                }
        },
    49:{
        "dict":{
            "drawcolor":"brown",
            "rclickBreak":True,
            "blitindex":14,
            "tile":True
        }
    },
    48:{
            "dict":{
                "drawcolor":"brown",
                "rclickBreak":True,
                "blitindex":13,
                "tile":True
            }
        },
    50:{
            "dict":{
                "drawcolor":"brown",
                "rclickBreak":True,
                "blitindex":15,
                "customwh":[100,50]
            }
        },
    51:{
                "dict":{
                    "drawcolor":"brown",
                    "rclickBreak":True,
                    "blitindex":16,
                    "customwh":[100,50]
                }
            },
    20:{
            "dict":{
                "drawcolor":"gray",
                "workbench":True,
                "wbtype":3,
                "wbpower":2,
                "rclickBreak":True,
                "blitindex":12,
                "gui":True,
                "upgradeitem":[59,21,21],
                "hpower":2,
                "upgradeblit":17
                }
        },
    

}

hammerdict={
    12:{
        "hpower":1
    },
    59:{
            "hpower":2
        }
}

weaponsdict={
    1:{
        "dmg":1,
        "cd":15
    },
    13:{
        "dmg":2,
        "cd":15
    },
    19:{
        "dmg":5,
        "cd":15
    },
    62:{
        "dmg":10,
        "cd":20
    }

}

backpackdict={
    55:{
        "slot":4
    }
}

fooddict={
    14:{
        "heal":1
    },
    15:{
        "heal":2
    }
}

armordict={
    22:{
        "protect":2
    },
    24:{
        "protect":1
    },
    60:{
        "protect":3
    },
    61:{
        "protect":2
    }
}

buildlist=[]

bulletlist=[]

biomelist=[]

biomematrix=[[0 for _ in range(201)] for _ in range(201)]
biomeinfo=[[0 for _ in range(201)] for _ in range(201)]

firstloop=1

ww,wh=window.get_size()

# biome tuning
BIOME_TILE_SIZE = 100
BIOME_SPREAD_RADIUS = 5
BIOME_MAX_TILES = 800

green=(0,255,0)
orange=(150,50,0)

oldrecipes=[]



upgradetxt=font.render("Required to upgrade:",True,"black")

linerect=pg.Rect(690,0,5,300)

time=2699
Dtime=-1
night=0
nightCount=0
vals=[
    [10,[0]],
    [8,[0]],
    [16,[0]],
    [24,[0]],
    [32,[0]],
    [48,[0]],
    [64,[0]],
    [512,[0]],
    [1024,[0]],
    [2048,[0]],
    [1280,[0]],
    [1280,[0]],
    [1280,[0]],
    [1280,[0]],
    [1280,[0]],
    [1280,[0]],
    [1280,[0]],
    [1280,[0]],
    [1280,[0]],
    [1280,[0]],
    [1280,[0]],
]

moblist=[]

omegafont=pg.font.Font(None,200)
youlosetxt=omegafont.render(f"You Survived {nightCount} nights.",True,"white")
omegarect=youlosetxt.get_rect(center=[960,540])
txt2=pg.font.Font(None,150).render("(Press ESC to quit)",True,"white")
rect2=txt2.get_rect(center=[960,650])

