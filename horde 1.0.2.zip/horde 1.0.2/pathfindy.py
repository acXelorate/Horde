from copy import deepcopy
    #0 is free space
    #1 is wall
    #2 is player
    #3 is destination
    #4 is trail
    #return [x offset, y offset] after 1 step
    #v1 only supports V=1
    #option B: create entire path at first, return class/list/dict, then make seperate function for getting step // I WILL USE MATRIX FOR PATH OBJECT
    #use option A for now, since option B is for when all objects are static other then self
    #option A is still to make entire path, so ig make a seperate function for QoL


    #first version 1 attempt?

def flip_matrix(matrix):
    return [list(row) for row in zip(*deepcopy(matrix))]

def get_direction(matrix,index,offset,player):

    if offset==0: return 0

    if index==0:
        Toffset=[offset,0]
    else:
        Toffset=[0,offset]
    Mindex=[player[0]+Toffset[0],player[1]+Toffset[1]]

    try: # is not on collision,
        if matrix[Mindex[0]][Mindex[1]]!=1:
            return Toffset
        else: return 0
    except:
        return 0

    



def get_path(matrix:list):
    path=[]
    a=0
    run=1
    while run:
        a+=1
        

        for x in range(len(matrix)):
            for y in range(len(matrix[x])):
                if matrix[x][y]==2:
                    player=[x,y]
                if matrix[x][y]==3:
                    dest=[x,y]
        dist=[dest[0]-player[0],dest[1]-player[1]]
        
        if abs(dist[0])>abs(dist[1]):
            index=0 #Y
            otherindex=1
        else:           #INDEX OF DIRECTION = [y,x]
            index=1 #X
            otherindex=0

        

        if dist[index]==0: offset=0
        else: offset=dist[index]//abs(dist[index])
        if dist[otherindex]==0: otheroffset=0
        else: otheroffset=dist[otherindex]//abs(dist[otherindex])

        if   get_direction(matrix,index,offset,player)!=0: direction=get_direction(matrix,index,offset,player)     #forwards
        elif get_direction(matrix,otherindex,otheroffset,player)!=0: direction=get_direction(matrix,otherindex,otheroffset,player)   #closer side
        elif get_direction(matrix,otherindex,-otheroffset,player)!=0: direction=get_direction(matrix,otherindex,-otheroffset,player)    #further side
        elif get_direction(matrix,index,-offset,player)!=0: direction=get_direction(matrix,index,-offset,player)    #backwards

        elif otheroffset==0:
            if   get_direction(matrix,otherindex,-1,player)!=0: direction=get_direction(matrix,otherindex,-1,player)
            elif get_direction(matrix,otherindex,1,player)!=0: direction=get_direction(matrix,otherindex,1,player)

            else: return path
        else: return path

        
        path.append(direction)
        matrix[player[0]][player[1]]=1
        matrix[player[0]+direction[0]][player[1]+direction[1]]=2
        
        
        run=0
        for i in matrix:
            for o in i:
                if o==3:
                    run=1
    return path

def get_state(matrix,path,i):
    
    mat = deepcopy(matrix)
    for x in range(len(mat)):
            for y in range(len(mat[x])):
                if mat[x][y]==2:
                    player=[x,y]
    step=path[i]
    mat[player[0]][player[1]]=4
    mat[player[0]+step[0]][player[1]+step[1]]=2

    return mat


def pathfind(matrix:list,flip=0):
    image=[]
    path=get_path(deepcopy(matrix))
    for i in range(len(path)):
        matrix=get_state(matrix,path,i)
        image.append(flip_matrix(matrix) if flip==1 else matrix)
    return image