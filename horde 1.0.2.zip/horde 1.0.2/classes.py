from consts import *
from functions import craft,pitagora

animychange=[0,1,0,1,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1]
animxchange=[0,0,0,0,0,0,0,1,1,1,0,0,0,0,0,0,0,0,1,1,1,0,0,0]

class Guy:
    def __init__(self,obblist:list,itemlist:list):

        self.Rect=pg.Rect(0,0,100,100)
        self.velocity=10
        self.obblist=obblist
        self.itemlist=itemlist
        self.animtype=0
        self.animindex=0
        self.animtick=0
        self.animlist=[[0,1],[2,4],[5,6],[7,9],[10,11],[12,14],[15,17],[18,20],[21,23]]
        self.hp=20
        self.animychange=[0,1,0,1,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1]
        self.animxchange=[0,0,0,0,0,0,0,1,1,1,0,0,0,0,0,0,0,0,1,1,1,0,0,0]

    def step(self):
        self.hasmoved=0
        self.hasinteracted=0

    def move(self,x,y,bool):
        if bool:
            self.Rect.x+=x
            self.Rect.y+=y

    def move_collide(self,x,y,bool):
        if bool:
            rectlist=[]
            for obb in self.obblist:
                bool="nocollision" in obb.p and obb.p["nocollision"]==True
                rectlist.append(obb.Rect if not bool else pg.Rect(0,0,0,0))

            self.Rect.x+=x
            self.Rect.y+=y
            if self.Rect.collidelist(rectlist)!=-1:
                self.Rect.x-=x
                self.Rect.y-=y
            else:
                if self.hasmoved==0:
                    if self.animtype not in [5,6,7,8]:
                        if x==10:
                                        if self.animtype!=1:
                                            self.animtype=1
                                            self.animtick=0
                                            self.animindex=self.animlist[self.animtype][0]
                                            
                                            
                        elif x==-10:
                                            if self.animtype!=3:
                                                self.animtype=3
                                                self.animtick=0
                                                self.animindex=self.animlist[self.animtype][0]
                    
                                                
                        elif y==10:
                                            if self.animtype!=2:
                                                self.animtype=2
                                                self.animtick=0
                                                self.animindex=self.animlist[self.animtype][0]
                                                            
                                                
                        elif y==-10:
                                            if self.animtype!=4:
                                                self.animtype=4
                                                self.animtick=0
                                                self.animindex=self.animlist[self.animtype][0]

                
                self.hasmoved=1
                      
                
                                        
                

    def draw(self,selecteditem,inv):
        global cam

        if self.hasinteracted==0 and self.hasmoved==0 and self.animtype!=0 and not self.animtype in [5,6,7,8]:
            self.animtype=0
            self.animtick=0
            self.animindex=0

        if self.animtick==5:
            self.animindex+=1
            if self.animindex>self.animlist[self.animtype][1]:
                if self.animtype in [5,6,7,8]:
                    self.animtype=0
                    self.animindex=0
                else:
                    self.animindex=self.animlist[self.animtype][0]
            self.animtick=0
        else: self.animtick+=1
        pgp.blit(window,cam,guysprites[self.animindex],self.Rect.x,self.Rect.y,False)
        keys=[i for i in sprites.keys()]
        for item in inv:
            if item in keys:
                pgp.blit(window,cam,sprites[item],self.Rect.x+self.animxchange[self.animindex],self.Rect.y+self.animychange[self.animindex],False)

        if self.animtype in [5,6,7,8] and selecteditem in itemmodelsprites:
            pgp.blit(window,cam,itemmodelsprites[selecteditem][self.animindex],self.Rect.x,self.Rect.y,False)
        
        #pgp.draw.rect(window,cam,"white",self.Rect,gui=False)

    def changecam(self):
        global cam
        cam.x=self.Rect.x-910 #910
        cam.y=self.Rect.y-490 #490
        return cam.x,cam.y

    def get_craft(self):
        crafts={None:1}
        for obb in obblist:
            if "workbench" in obb.p and obb.p["workbench"]==True and sqrt((obb.Rect.centerx-self.Rect.centerx)**2+(obb.Rect.centery-self.Rect.centery)**2)<500:
                if obb.p["wbtype"] not in crafts or (obb.p["wbtype"] in crafts and crafts[obb.p["wbtype"]]<obb.p["wbpower"]>crafts[obb.p["wbtype"]]):
                    crafts[obb.p["wbtype"]]=obb.p["wbpower"]

        return crafts

    def pickup(self,bool,inv):
        
        rectlist=[]
        for item in self.itemlist:
            rectlist.append(item.Rect)
        index=self.Rect.collidelist(rectlist)
        if index!=-1:
            self.itemlist[index].selected=1
            if bool and 0 in inv:
                itemindex=inv.index(0)
                inv[itemindex]=self.itemlist[index].itemid
                self.itemlist.pop(index)

    def leftclick(self,selectedItem,toolcd,mousex,mousey,_bool,inv=[],slot=0,gui1=0,bool2=0):
        # convert screen mouse coords to world coords (undo scaling and camera offset)
        mx_world = mousex / cam.scale[0] + cam.x
        my_world = mousey / cam.scale[1] + cam.y
        # compute angle from player center to mouse (degrees, -180..180)
        vec = pg.math.Vector2(mx_world - self.Rect.centerx, my_world - self.Rect.centery)
        _, angle = vec.as_polar()
        angle = ((angle + 180) % 360) - 180

        rectlist = [obb.Rect for obb in self.obblist]
        index=pgp.rect.collidelistpoint2(rectlist,mx_world,my_world)
        if index!=-1:
            obb=obblist[index]
            if "gui" in obb.p and obb.p["gui"]==True and gui1==0:
                pgp.draw.rect(window,cam,"gray",obbguirect)
                pgp.draw.rect(window,cam,"black",obbguirect,5)
                pgp.draw.rect(window,cam,"black",linerect)
                img=pg.transform.scale(obbsprites[obb.p["blitindex"]],(200,200))
                pgp.blit(window,cam,img,450,50)
                pgp.blit(window,cam,upgradetxt,700,10)
                x=700
                if obb.p["upgradeitem"]!=-1:
                    for item in obb.p["upgradeitem"]:
                        img=pg.transform.scale(itemsprites[item],(200,200))
                        pgp.blit(window,cam,img,x,100)
                        x+=220
                    if selectedItem in hammer and hammerdict[selectedItem]["hpower"]>=obb.p["hpower"] and _bool:
                        val=craft(True,inv,obb.p["upgradeitem"],[],self.Rect)
                        if val!=inv:
                            inv[:]=val
                            obblist[index].p["wbpower"]+=2
                            obblist[index].p["upgradeitem"]=-1
                            obblist[index].p["blitindex"]=obb.p["upgradeblit"]
                            self.hasinteracted=1
                            if -45 <= angle <= 45:
                                self.animtype = 6
                            elif 45 < angle <= 135:
                                self.animtype = 5
                            elif angle > 135 or angle <= -135:
                                self.animtype = 7
                            else:
                                self.animtype = 8
                            self.animindex = self.animlist[self.animtype][0]
                            self.animtick = 0



        # decrement cooldown over time so mining can happen again after a valid hit
        if toolcd > 0:
            toolcd -= 1

        if toolcd == 0:
           
            

            if round(sqrt((self.Rect.centerx-mx_world)**2+(self.Rect.centery-my_world)**2)) < 300 and _bool:
                if selectedItem in tools:
                    # determine which obb (if any) the mouse is over using world coords
                    index = -1
                    for i, r in enumerate(rectlist):
                        if r.collidepoint(mx_world, my_world):
                            index = i
                            break

                    if index != -1 and 0 <= index < len(self.obblist):
                        target = self.obblist[index]

                        if (target.p.get("breakable") == True
                                and target.p.get("btype") == tooldict[selectedItem].get("breaktype")
                                and target.p.get("bpower", 0) < tooldict[selectedItem].get("toolpower", 0)):

                            target.p["hp"] = target.p.get("hp", 0) - (tooldict[selectedItem].get("toolpower", 0) - target.p.get("bpower", 0))
                            toolcd = tooldict[selectedItem]["cd"]
                            _bool=0
                            self.hasinteracted=1
                            if tooldict[selectedItem].get("breaktype")=="bucket":
                                inv[slot]=0

                            if -45 <= angle <= 45:
                                self.animtype = 6
                            elif 45 < angle <= 135:
                                self.animtype = 5
                            elif angle > 135 or angle <= -135:
                                self.animtype = 7
                            else:
                                self.animtype = 8
                            self.animindex = self.animlist[self.animtype][0]
                            self.animtick = 0

                if selectedItem in weapons:
                    
                    rectlist2=[]
                    for mob in moblist:
                        rectlist2.append(mob.Rect)
                    mob=pgp.rect.collidelistpoint2(rectlist2,mx_world,my_world)
                    if mob!=-1:
                        dmg=weaponsdict[selectedItem]["dmg"]
                        for item in moblist[mob].inv:
                            if item in armor:
                                dmg-=armordict[item]["protect"]
                        if dmg<1: dmg=1
                        moblist[mob].hp-=dmg
                        toolcd=weaponsdict[selectedItem]["cd"]
                        self.hasinteracted=1
                        
                        if -45 <= angle <= 45:
                            self.animtype = 6
                        elif 45 < angle <= 135:
                            self.animtype = 5
                        elif angle > 135 or angle <= -135:
                            self.animtype = 7
                        else:
                            self.animtype = 8
                        self.animindex = self.animlist[self.animtype][0]
                        self.animtick = 0

        if selectedItem in build and _bool and bool2:
            
            buildlist.append(Build(
                self.Rect.copy(),
                builddict[selectedItem]["dict"].copy(),))
            inv[slot]=0
            _bool=0

        if selectedItem in food and _bool and self.hp<20:
            self.hp+=fooddict[selectedItem]["heal"]
            inv[slot]=0
            _bool=0

        return toolcd,_bool

    def die(self,inv):
        if self.hp<=0:
            for item in inv:
                if item!=0:
                    itemlist.append(Item(self.Rect.copy(),item))
            inv=[0,0,0]
            self.hp=20
            self.Rect.x=0
            self.Rect.y=0
        return inv

    def hardcore(self):
        if self.hp<=0:
            return 2
        return 1

class Obb:
    def __init__(self,Rect,p):
        self.p=copy({
            "drawcolor":"brown"
        })
        self.p.update(p)
        self.Rect=Rect

        if self.Rect.x==0 and self.Rect.y==0:
            self.p["nocollision"]=True
    def draw(self):                 
        global cam,itemsprites
        if pgp.rect.colliderect1(cam,self.Rect,camrect):
            if "blitindex" in self.p:
                pgp.blit(window,cam,obbsprites[self.p["blitindex"]],self.Rect.x,self.Rect.y,False)
            else:
                pgp.draw.rect(window,cam,self.p["drawcolor"],self.Rect,gui=False)
            #pgp.blit(window,cam,font.render(str(self.p["hp"]),True,"white"),self.Rect.x,self.Rect.y,False)

    def die(self):
        if "hp" in self.p and self.p["hp"] <= 0:
            if "drop" in self.p and self.p["drop"] != 0:
                itemlist.append(
                    Item(
                        pg.Rect(self.Rect.x, self.Rect.y, 100, 100),
                        self.p["drop"]
                    )
                )

            return True

        return False

    

class Item:
    def __init__(self,Rect:pg.Rect,itemId):
        self.Rect=Rect
        self.itemid=itemId

    def draw(self):
        #pgp.draw.rect(window,cam,"gray",self.Rect,gui=False)
        if pgp.rect.colliderect1(cam,self.Rect,camrect):
            pgp.blit(window,cam,itemsprites[self.itemid],self.Rect.x,self.Rect.y,False)

class Bullet:
    def __init__(self,Rect:pg.Rect,p):
        self.Rect=Rect
        self.p=p

    def step(self):
        
        pgp.draw.rect(window,cam,"blue",self.Rect,gui=False)
        if "tooltype" in self.p:
            obbrectlist=[]
            for obb in obblist:
                obbrectlist.append(obb.Rect)
            indexes=self.Rect.collidelistall(obbrectlist)
            willbreak=[]
            for i in indexes:
                if "breakable" in obblist[i].p and obblist[i].p["brekable"]==True:
                    if obblist[i].p["btype"]==self.p["tooltype"]:
                        if obblist[i].p["bpower"]<self.p["toolpower"]:
                            obblist[i].p["hp"]-=self.p["toolpower"]-obblist[i].p["toolpower"]
                            if obblist[i].p["hp"]<=0:
                                willbreak.append(i)
            for i in willbreak:
                itemlist.append(Item(obblist[i].Rect,obblist[i].p["drop"]))
                obblist.pop(i)
                i+=1
            
        
        bulletlist.remove(self)

class Build:
    def __init__(self,Rect:pg.Rect,p):
        self.Rect=Rect
        self.p=p
        self.state=0
        if "customwh" in p:
            self.Rect.w,self.Rect.h=p["customwh"]

    def step(self,rect,bool2,x,y):
        self.Rect.centerx=x
        self.Rect.centery=y
        self.Rect.x=floor(self.Rect.x/100)*100
        self.Rect.y=floor(self.Rect.y/100)*100
        rectlist=[]
        for obb in obblist:
            rectlist.append(obb.Rect)
        for item in itemlist:
            rectlist.append(item.Rect)
        
        rectlist.append(rect)
        rectlist2 = [t.Rect for t in tileobblist]

        # If this build is a tile, allow placement everywhere except when
        # it would collide with another tile. For non-tile builds, keep
        # previous behavior: must not collide with main objects/items/rect.
        if self.p.get("tile") is True:
            can_place = (self.Rect.collidelist(rectlist2) == -1)
        else:
            can_place = (self.Rect.collidelist(rectlist) == -1)

        if can_place:
            self.state = 1
            if bool2:
                new_rect = self.Rect.copy()
                if self.p.get("tile") is True:
                    tileobblist.append(Obb(new_rect, self.p.copy()))
                else:
                    obblist.append(Obb(new_rect, self.p.copy()))
                if self in buildlist:
                    buildlist.remove(self)
        else:
            self.state = 0
            

    def draw(self):
        if self.state==0:
            pgp.draw.rect(window,cam,"red",self.Rect,gui=False)
        else:
            pgp.draw.rect(window,cam,"darkgreen",self.Rect,gui=False)
            
colorlist={"forest":"orange","cave":"darkgray","hell":(100,50,50)}

class Biome:
    def __init__(self,Rect,type,growth):
        self.Rect=Rect
        self.type=type
        self.growth=growth
        self.color=colorlist[type]

    def draw(self):
        if pgp.rect.colliderect1(cam,self.Rect,camrect):
            pgp.draw.rect(window,cam,self.color,self.Rect,gui=False)

animlist=[[0,1],[2,4],[5,6],[7,9],[10,11],[12,14],[15,17],[18,20],[21,23]]

class Mob:
    def __init__(self,Rect:pg.Rect,inv=None):
        self.tick=0
        self.path=[]
        self.Rect=Rect
        self.atick=0
        self.aspeed=60
        self.hp=20
        self.animtype=0
        self.animtick=0
        self.animindex=0
        self.animlist=animlist.copy()
        if inv is None:
            inv=[]
        self.inv=inv

    def move(self,matrix,centerx,centery,rect):
        if len(moblist)<-1:
            try:
                if self.tick%10==0:
                    matrix[self.Rect.x//100+100][self.Rect.y//100+100]=2
                    matrix=[i[centerx-50:centerx+50] for i in matrix[centery-50:centerx+50]]
                    self.path=pf.get_path(matrix)[0]
                self.Rect.x+=self.path[0]*10
                self.Rect.y+=self.path[1]*10
                self.tick+=1
                
            except:
                pass
        else:
            if not pitagora(self.Rect.center,rect.center,100):
                dx = self.Rect.x - rect.x
                dy = self.Rect.y - rect.y
                distx = copysign(7, dx) if abs(dx) > 6 else 0
                disty = copysign(7, dy) if abs(dy) > 6 else 0
                
                self.Rect.x -= distx
                self.Rect.y -= disty
                rectlist=[]
                for tile in obblist:
                    rectlist.append(tile.Rect)
                if self.Rect.collidelist(rectlist)!=-1:
                    self.Rect.x+=distx
                    self.Rect.y+=disty
                    if self.animtype!=0:
                        self.animtype=0
                        self.animindex=0
                        self.animtick=0

                # if mob moved, choose animation based on angle to target `rect`
                if distx != 0 or disty != 0:
                    vec = pg.math.Vector2(rect.centerx - self.Rect.centerx, rect.centery - self.Rect.centery)
                    _, angle = vec.as_polar()
                    angle = ((angle + 180) % 360) - 180

                    # Map angle sectors to movement animtypes (right=1, down=2, left=3, up=4)
                    if -45 <= angle <= 45:
                        target_anim = 1
                    elif 45 < angle <= 135:
                        target_anim = 2
                    elif angle > 135 or angle <= -135:
                        target_anim = 3
                    else:
                        target_anim = 4

                    if self.animtype != target_anim:
                        self.animtype = target_anim
                        self.animindex = self.animlist[self.animtype][0]
                        self.animtick = 0
            

    def draw(self):
        if self.animtick==5:
            self.animtick=0
            self.animindex+=1
            if self.animindex>self.animlist[self.animtype][1]:
                if self.animtype in [5,6,7,8]:
                    self.animindex=0
                    self.animtype=0
                else:
                    self.animindex=self.animlist[self.animtype][0]
        else: self.animtick+=1
        pgp.blit(window,cam,mobsprites[self.animindex],self.Rect.x,self.Rect.y,False)
        keys=[i for i in sprites.keys()]
        for item in self.inv:
            if item in keys:
                
                pgp.blit(window,cam,sprites[item],self.Rect.x+animxchange[self.animindex],self.Rect.y+animychange[self.animindex],False)
            
                

        for selecteditem in self.inv:
            temp=[i for i in itemmodelsprites.keys()]
            if self.animtype in [5,6,7,8] and selecteditem in temp:
                
                pgp.blit(window,cam,itemmodelsprites[selecteditem][self.animindex],self.Rect.x,self.Rect.y,False)
            
        #pgp.draw.rect(window,cam,"red",self.Rect,gui=False)

    def attack(self,guyrect:pg.Rect,hp,inv):
        if pitagora(self.Rect.center,guyrect.center,100):
            if self.atick==self.aspeed:
                self.atick=0
                dmg=1
                for item in self.inv:
                    if item in weapons:
                        dmg+=weaponsdict[item]["dmg"]
                
                for item in inv:
                    if item in armor:
                        dmg-=armordict[item]["protect"]
                if dmg<1:
                    dmg=1
                hp-=dmg
                vec = pg.math.Vector2(guyrect.centerx - self.Rect.centerx, guyrect.centery - self.Rect.centery)
                _, angle = vec.as_polar()
                angle = ((angle + 180) % 360) - 180
                if -45 <= angle <= 45:
                    self.animtype = 6
                elif 45 < angle <= 135:
                    self.animtype = 5
                elif angle > 135 or angle <= -135:
                    self.animtype = 7
                else:
                    self.animtype = 8
                self.animindex = self.animlist[self.animtype][0]
                self.animtick = 0
                
                
            else:
                self.atick+=1
        else:
            self.atick=0

        return hp


    def burn(self,check):
        if check:
            self.hp-=1
        if self.hp<=0:
            moblist.remove(self)

class Detail:
    def __init__(self,Rect,type):
        self.Rect=Rect
        self.type=type
    def draw(self):
        if pgp.rect.colliderect1(cam,self.Rect,camrect):
            pgp.blit(window,cam,detailsprites[self.type],self.Rect.x,self.Rect.y,False)