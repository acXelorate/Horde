from consts import *
from classes import *
from functions import *


from datetime import datetime
first=datetime.now()
min=first.minute
sec=first.second
print("Started game",min,sec)
#KNOWN BUGS: CRAFTPAGE DOESNT UPDATE IF YOU SWITCH FROM A BETTER WB TO A WORSE WB IN SAME CATEGORY

guy=Guy(obblist,itemlist)

craftpage=0

tilelist=[]

i=0

Temp=Mob(pg.Rect(200,0,100,100))

for _ in range(12):
    x=random.randint(-100,100)+100
    y=random.randint(-100,100)+100
    biomematrix[x][y]=250



for _ in range(25):
    grow_biome()

obblist.append(Obb(pg.Rect(-10100,-10100,20200,100),{"drawcolor":"gray"}))
obblist.append(Obb(pg.Rect(-10100,-10100,100,20200),{"drawcolor":"gray"}))
obblist.append(Obb(pg.Rect(10000,-10100,100,20200),{"drawcolor":"gray"}))
obblist.append(Obb(pg.Rect(-10100,10000,20200,100),{"drawcolor":"gray"}))

for row,list in enumerate(biomematrix):
    for col,tile in enumerate(list):
        if tile>0:
            biomelist.append(Biome(pg.Rect((col-100)*100,(row-100)*100,100,100),"forest",0))

first=datetime.now()
min=first.minute
sec=first.second
print("Generated Forest",min,sec)

biomematrix[:]=[[0 for _ in range(201)] for _ in range(201)]


for _ in range(15):
    x=random.randint(-100,100)+100
    y=random.randint(-100,100)+100
    biomematrix[x][y]=100


for _ in range(10):
    grow_biome()

for row,list in enumerate(biomematrix):
    for col,tile in enumerate(list):
        if tile>0:
            biomelist.append(Biome(pg.Rect((col-100)*100,(row-100)*100,100,100),"cave",0))

biomematrix[:]=[[0 for _ in range(201)] for _ in range(201)]


for _ in range(5):
    x=random.randint(-100,100)+100
    y=random.randint(-100,100)+100
    biomematrix[x][y]=150


for _ in range(15):
    grow_biome()

for row,list in enumerate(biomematrix):
    for col,tile in enumerate(list):
        if tile>0:
            biomelist.append(Biome(pg.Rect((col-100)*100,(row-100)*100,100,100),"hell",0))

first=datetime.now()
min=first.minute
sec=first.second
print("Generated Cave",min,sec)


rectlist1=[]
for biome in biomelist:
    if biome.type=="forest":
        rectlist1.append(biome.Rect)

rectlist2=[]
for biome in biomelist:
    if biome.type=="cave":
        rectlist2.append(biome.Rect)

rectlist3=[]
for biome in biomelist:
    if biome.type=="hell":
        rectlist3.append(biome.Rect)

for _ in range(800):
    x=random.randint(-100,100)*100
    y=random.randint(-100,100)*100
    if (x,y) not in tilelist and pgp.rect.collidelistpoint2(rectlist3,x,y)==-1:
        obblist.append(Obb(pg.Rect(x,y,100,50),
                           {"drawcolor":darkgray,
                            "breakable":True,
                            "btype":"rock",
                            "bpower":0,
                            "hp":5,
                            "drop":3,
                            "blitindex":0
                            }))
        tilelist.append((x,y))

for _ in range(200):
    x=random.randint(-100,100)*100
    y=random.randint(-100,100)*100
    if (x,y) not in tilelist and pgp.rect.collidelistpoint2(rectlist3,x,y)==-1:
        obblist.append(Obb(pg.Rect(x,y,100,50),
                           {"drawcolor":darkgray,
                            "breakable":True,
                            "btype":"rock",
                            "bpower":2,
                            "hp":5,
                            "drop":32,
                            "blitindex":5
                            }))
        tilelist.append((x,y))

first=datetime.now()
min=first.minute
sec=first.second
print("Generated Rock",min,sec)



for _ in range(800):
    x=random.randint(-100,100)*100
    y=random.randint(-100,100)*100
    if (x,y) not in tilelist and pgp.rect.collidelistpoint2(rectlist1,x,y)!=-1 and pgp.rect.collidelistpoint2(rectlist3,x,y)==-1 and pgp.rect.collidelistpoint2(rectlist2,x,y)==-1:
        obblist.append(Obb(pg.Rect(x,y,100,100),
                           {
                               "drawcolor":"brown",
                               "breakable":True,
                               "btype":"wood",
                               "bpower":0,
                               "hp":5,
                               "drop":5,
                               "blitindex":2
                           }))
        tilelist.append((x,y))

first=datetime.now()
min=first.minute
sec=first.second
print("Generated Trees",min,sec)



for _ in range(1200):
    x=random.randint(-100,100)*100
    y=random.randint(-100,100)*100
    if (x,y) not in tilelist and pgp.rect.collidelistpoint2(rectlist2,x,y)!=-1 and pgp.rect.collidelistpoint2(rectlist3,x,y)==-1:
        obblist.append(Obb(pg.Rect(x,y,100,50),
                           {
                               "drawcolor":"lightgray",
                               "breakable":True,
                               "btype":"rock",
                               "bpower":1,
                               "hp":5,
                               "drop":10,
                               "blitindex":3
                           }))
        tilelist.append((x,y))

first=datetime.now()
min=first.minute
sec=first.second
print("Generated Iron",min,sec)

for _ in range(1200):
    x=random.randint(-100,100)*100
    y=random.randint(-100,100)*100
    if (x,y) not in tilelist and pgp.rect.collidelistpoint2(rectlist2,x,y)!=-1 and pgp.rect.collidelistpoint2(rectlist3,x,y)==-1:
        obblist.append(Obb(pg.Rect(x,y,100,50),
                           {
                               "drawcolor":"lightgray",
                               "breakable":True,
                               "btype":"rock",
                               "bpower":1,
                               "hp":5,
                               "drop":8,
                               "blitindex":4
                           }))
        tilelist.append((x,y))

first=datetime.now()
min=first.minute
sec=first.second
print("Generated Coal",min,sec)



for _ in range(600):
    x=random.randint(-100,100)*100
    y=random.randint(-100,100)*100
    if (x,y) not in tilelist and pgp.rect.collidelistpoint2(rectlist3,x,y)!=-1:
        obblist.append(Obb(pg.Rect(x,y,100,100),
                           {
                               "drawcolor":"lightgray",
                               "breakable":True,
                               "btype":"rock",
                               "bpower":2,
                               "hp":5,
                               "drop":30,
                               "blitindex":6
                           }))
        tilelist.append((x,y))

for _ in range(600):
    x=random.randint(-100,100)*100
    y=random.randint(-100,100)*100
    if (x,y) not in tilelist and pgp.rect.collidelistpoint2(rectlist3,x,y)!=-1:
        obblist.append(Obb(pg.Rect(x,y,100,50),
                           {
                               "drawcolor":"lightgray",
                               "breakable":True,
                               "btype":"bucket",
                               "bpower":0,
                               "hp":1,
                               "drop":29,
                               "blitindex":8
                           }))
        tilelist.append((x,y))

for _ in range(600):
    x=random.randint(-100,100)*100
    y=random.randint(-100,100)*100
    if (x,y) not in tilelist and pgp.rect.collidelistpoint2(rectlist2,x,y)!=-1 and pgp.rect.collidelistpoint2(rectlist3,x,y)==-1:
        obblist.append(Obb(pg.Rect(x,y,100,50),
                           {
                               "drawcolor":"lightgray",
                               "breakable":True,
                               "btype":"bucket",
                               "bpower":0,
                               "hp":1,
                               "drop":28,
                               "blitindex":7
                           }))
        tilelist.append((x,y))



for _ in range(400):
    x=random.randint(-100,100)*100
    y=random.randint(-100,100)*100
    if (x,y) not in tilelist and pgp.rect.collidelistpoint2(rectlist3,x,y)==-1:
        itemlist.append(Item(pg.Rect(x,y,100,100),1))
        tilelist.append((x,y))

for _ in range(100):
    x=random.randint(-100,100)*100
    y=random.randint(-100,100)*100
    if (x,y) not in tilelist and pgp.rect.collidelistpoint2(rectlist3,x,y)==-1:
        itemlist.append(Item(pg.Rect(x,y,100,100),52))
        tilelist.append((x,y))

for _ in range(50):
    x=random.randint(-100,100)*100
    y=random.randint(-100,100)*100
    if (x,y) not in tilelist and pgp.rect.collidelistpoint2(rectlist3,x,y)==-1:
        itemlist.append(Item(pg.Rect(x,y,100,100),14))
        tilelist.append((x,y))



first=datetime.now()
min=first.minute
sec=first.second
print("Generated Sticks",min,sec)

for _ in range(800):
    x=random.randint(-100,100)*100
    y=random.randint(-100,100)*100
    if (x,y) not in tilelist and pgp.rect.collidelistpoint2(rectlist3,x,y)==-1 and pgp.rect.collidelistpoint2(rectlist2,x,y)==-1 and pgp.rect.collidelistpoint2(rectlist1,x,y)==-1:
        details.append(Detail(pg.Rect(x,y,100,100),random.randint(0,2)))
        tilelist.append((x,y))

for _ in range(200):
    x=random.randint(-100,100)*100
    y=random.randint(-100,100)*100
    if (x,y) not in tilelist and pgp.rect.collidelistpoint2(rectlist3,x,y)==-1 and pgp.rect.collidelistpoint2(rectlist2,x,y)==-1 and pgp.rect.collidelistpoint2(rectlist1,x,y)!=-1:
        details.append(Detail(pg.Rect(x,y,100,100),random.randint(3,5)))
        tilelist.append((x,y))

""" for _ in range(200):
    x=random.randint(-100,100)*100
    y=random.randint(-100,100)*100
    if (x,y) not in tilelist and pgp.rect.collidelistpoint2(rectlist3,x,y)==-1 and pgp.rect.collidelistpoint2(rectlist2,x,y)!=-1 and pgp.rect.collidelistpoint2(rectlist1,x,y)==-1:
        details.append(Detail(pg.Rect(x,y,100,100),random.randint(6,8)))
        tilelist.append((x,y)) """

for _ in range(200):
    x=random.randint(-100,100)*100
    y=random.randint(-100,100)*100
    if (x,y) not in tilelist and pgp.rect.collidelistpoint2(rectlist3,x,y)!=-1 and pgp.rect.collidelistpoint2(rectlist2,x,y)==-1 and pgp.rect.collidelistpoint2(rectlist1,x,y)==-1:
        details.append(Detail(pg.Rect(x,y,100,100),random.randint(6,8)))
        tilelist.append((x,y))

while run:
    sdn=0
    sup=0
    
    mousex,mousey=pg.mouse.get_pos()
    keys=pg.key.get_pressed()
    leftclick=0
    enter=0
    one=0
    two=0
    tri=0
    for event in pg.event.get():
        if event.type==pg.QUIT:
            run=0
        if event.type==pg.MOUSEBUTTONDOWN:
            if event.button==1:
                leftclick=1
        if event.type==pg.KEYDOWN:
            if event.key in [pg.K_RETURN,pg.K_KP_ENTER]:
                enter=1
            if event.key==pg.K_ESCAPE:
                if room==2:
                    run=0
                if room==1:
                    room=0
                    """ if pausemenu:
                        pausemenu=0
                    else:
                        pausemenu=1 """
            if gui2==0:
                if event.key==pg.K_1 and room==1:
                    invslot=0
                if event.key==pg.K_2 and room==1:
                    invslot=1
                if event.key==pg.K_3 and room==1:
                    invslot=2
            if event.key==pg.K_1:
                one=1
            if event.key==pg.K_2:
                two=1
            if event.key==pg.K_3:
                tri=1
            if event.key==pg.K_q and room==1:
                inv=drop(inv,invslot,guy.Rect)
            
        if event.type==pg.MOUSEWHEEL:
            if event.y==1:
                sup=1
            if event.y==-1:
                sdn=-1
    if 0==1: pass
    elif room==0:
        window.fill((0,255,0))
        for x in range(0,1920,200):
            pgp.draw.rect(window,cam,(0,200,0),pg.Rect(x,0,100,1080))
        pgp.blit(window,cam,goo,150,0)
        pgp.blit(window,cam,goo,1500,0)
        pgp.blit(window,cam,gooflip,790,0)
        pgp.blit(window,cam,gooflip2,310,780)
        pgp.blit(window,cam,gooflip3,1230,780)
        pgp.blit(window,cam,gooflip2,900,780)
        pgp.draw.rect(window,cam,(0,150,0),rect1,border_radius=20)
        pgp.draw.rect(window,cam,"black",rect1,5,border_radius=20)
        pgp.draw.rect(window,cam,(0,150,0),rect22,border_radius=20)
        pgp.draw.rect(window,cam,"black",rect22,5,border_radius=20)
        pgp.blit(window,cam,introtxt,introrect.x,introrect.y)

        if demomode:
            pgp.blit(window,cam,credtxt2,credrect.x,credrect.y)
        else:
            pgp.blit(window,cam,credtxt,credrect.x,credrect.y)

        if pgp.rect.collidepoint(cam,credrect,mousex,mousey) and leftclick:
            if demomode:
                demomode=0
            else:
                demomode=1
        
        if  pgp.rect.collidepoint(cam,rect1,mousex,mousey):
            pgp.blit(window,cam,playtxt2,playrect.x,playrect.y)
        else:
            pgp.blit(window,cam,playtxt,playrect.x,playrect.y)

        if  pgp.rect.collidepoint(cam,rect22,mousex,mousey):
            pgp.blit(window,cam,exittxt2,exitrect.x,exitrect.y)
        else:
            pgp.blit(window,cam,exittxt,exitrect.x,exitrect.y)

        if pgp.rect.collidepoint(cam,rect1,mousex,mousey) and leftclick:
            room=1
            if demomode:
                inv[:]=[0,0,0,49,51,24,19]
        if pgp.rect.collidepoint(cam,rect22,mousex,mousey) and leftclick:
            run=0
            print("ok")
        
    elif room==1:

        matrix=convert_to_matrix()
        xx=guy.Rect.x//100+100
        yy=guy.Rect.y//100+100
        matrix[xx][yy]=3



        window.fill((0,200,0))
        guy.step()

        
        guy.move_collide(0,-10,keys[pg.K_w])
        guy.move_collide(0,10,keys[pg.K_s])
        guy.move_collide(-10,0,keys[pg.K_a])
        guy.move_collide(10,0,keys[pg.K_d])

        for biome in biomelist:
            biome.draw()

        for detail in details:
            detail.draw()

        for tile in tileobblist:
            tile.draw()
            if obb.die():
                try:
                    obblist.remove(obb)
                except ValueError:
                    pass

        for item in itemlist:
            item.draw()

        for obb in obblist.copy():
            obb.draw()
            if obb.die():
                try:
                    obblist.remove(obb)
                except ValueError:
                    pass
        #Temp.move(0,xx,yy,guy.Rect)
        #Temp.draw()
        #Temp.burn(night==0)
        for Temp in moblist:    
                    
                    Temp.move([],xx,yy,guy.Rect)
                    guy.hp=Temp.attack(guy.Rect,guy.hp,inv)
                    Temp.draw()
                    Temp.burn(night==0)

        #inv=guy.die(inv)
        room=guy.hardcore()

        invslots=3
        for item in inv:
            if item in backpack:
                
                temp=3+backpackdict[item]["slot"]
                invslots=temp if temp>invslots else invslots

        while len(inv)<invslots:
            inv.append(0)

        if len(inv)>invslots:
            
            for i in range(len(inv)-1,invslots-1,-1):
                if inv[i]!=0:
                    itemlist.append(Item(guy.Rect.copy(),inv[i]))
            inv=inv[:invslots]

        if gui1==False:
            if sup:
                invslot=conv(invslot-1,3)
            if sdn:
                invslot=conv(invslot+1,3)

        

        unlockedr=guy.get_craft()
        guy.pickup(enter,inv)
        toolcd,leftclick=guy.leftclick(inv[invslot],toolcd,mousex,mousey,leftclick,inv,invslot,gui1,gui1==0 and gui2==0)
        
        cam.x,cam.y=guy.changecam()
        guy.draw(inv[invslot],inv)

        mouse_world_x = mousex / cam.scale[0] + cam.x
        mouse_world_y = mousey / cam.scale[1] + cam.y

        for build in buildlist:
            build.step(guy.Rect,leftclick,mouse_world_x,mouse_world_y)
            build.draw()

        if craftcategory not in unlockedr:
            
            craftcategory=None
            craftpage=0

        if gui2==0:
            pgp.draw.rect(window,cam,"gray",gui2rect1)
            pgp.draw.rect(window,cam,"black",gui2rect1,5)
            if pgp.rect.collidepoint(cam,gui2rect1,mousex,mousey):
                gui2=1
        else:
            pgp.draw.rect(window,cam,"gray",gui2rect2)
            pgp.draw.rect(window,cam,"black",gui2rect2,5)
            index=3
            running=1
            if len(inv)>index:
                for y in range(70,1000,120):
                    for x in range(1440,1920,120):
                        rect=pg.Rect(x,y,100,100)
                        import pgplus as pgp
                        pgp.draw.rect(window,cam,"darkgray",rect)
                        pgp.draw.rect(window,cam,"black",rect,5)
                        pgp.blit(window,cam,itemsprites[inv[index]],x,y)
                        if pgp.rect.collidepoint(cam,rect,mousex,mousey):
                            if one:
                                temp_=inv[0]
                                inv[0]=inv[index]
                                inv[index]=temp_
                            if two:
                                temp_=inv[1]
                                inv[1]=inv[index]
                                inv[index]=temp_
                            if tri:
                                temp_=inv[2]
                                inv[2]=inv[index]
                                inv[index]=temp_
                            if keys[pg.K_q]:
                                if inv[index]!=0:
                                    itemlist.append(Item(guy.Rect.copy(),inv[index]))
                                    inv[index]=0

                        index+=1
                        if index>len(inv)-1:
                            running=False
                            break
                    if not running:
                        break


                    

            if not pgp.rect.collidepoint(cam,gui2rect2,mousex,mousey):
                gui2=0

        if gui1==0:
            pgp.draw.rect(window,cam,"gray",gui1rect1)
            pgp.draw.rect(window,cam,"black",gui1rect1,5)
            if pgp.rect.collidepoint(cam,gui1rect1,mousex,mousey):
                gui1=1
        else:
            maxpage=0
            for i in unlockedr.values():
                maxpage+=i*3

            compage=3
            l=[i for i in unlockedr.values()]
            for _,o in enumerate(unlockedr.keys()):
                i=l[_]
                if o==craftcategory:
                    compage+=craftpage
                    break
                else:
                    compage+=l[_]*3
            
            if sdn and compage<maxpage:
                
                
                craftpage+=3
                if craftpage>(unlockedr[craftcategory]*3)-1:
                    
                    
                    craftcategory=[i for i in unlockedr.keys()][[i for i in unlockedr.keys()].index(craftcategory)+1]
                    
                    craftpage=0

            if sup and (craftpage>0 or craftcategory!=None):
                
                craftpage-=3
                if craftpage<0:
                    
                    temp=[i for i in unlockedr.keys()]
                    craftcategory=temp[temp.index(craftcategory)-1]
                    craftpage=unlockedr[craftcategory]*3-3

            
            pgp.draw.rect(window,cam,"gray",gui1rect2)
            pgp.draw.rect(window,cam,"black",gui1rect2,5)
            

            if not pgp.rect.collidepoint(cam,gui1rect2,mousex,mousey):
                gui1=0
            craftindex=craftpage
            y=300
            for _ in range(3):
                txt=""
                
                for char in recipes.copy()[craftcategory][craftindex][0]:
                    txt+=f"{char}+"
                
                    
                txt=txt[:-1]
                txt+="="
                for char in recipes.copy()[craftcategory][craftindex][1]:
                    txt+=f"{char}+"
                txt=txt[:-1]
                blitRich(txt,50,y-100)
                rect=pg.Rect(50,y,400,100)
                pgp.draw.rect(window,cam,(200,0,0),rect,border_radius=20)
                pgp.draw.rect(window,cam,"black",rect,3,border_radius=20)
                quickrect=crafttxt.get_rect(center=rect.center)
                pgp.blit(window,cam,crafttxt,quickrect.x,quickrect.y)
                if leftclick and pgp.rect.collidepoint(cam,rect,mousex,mousey):
                    inv=craft(True,inv,recipes.copy()[craftcategory][craftindex][0],recipes.copy()[craftcategory][craftindex][1],guy.Rect)
                
                craftindex+=1
                y+=300

        pgp.draw.rect(window,cam,"gray" if invslot!=0 else darkgray,inv1)
        pgp.draw.rect(window,cam,"gray" if invslot!=1 else darkgray,inv2)
        pgp.draw.rect(window,cam,"gray" if invslot!=2 else darkgray,inv3)
        pgp.draw.rect(window,cam,"black",inv1,10)
        pgp.draw.rect(window,cam,"black",inv2,10)
        pgp.draw.rect(window,cam,"black",inv3,10)
        pgp.blit(window,cam,itemsprites[inv[0]],inv1.x,inv1.y)
        pgp.blit(window,cam,itemsprites[inv[1]],inv2.x,inv2.y)
        pgp.blit(window,cam,itemsprites[inv[2]],inv3.x,inv3.y)

        time+=Dtime
        if time==3600:
           Dtime=-1
        if time==0:
            Dtime=1
        if time==2700:
            if Dtime==1:
                night=1
                nightCount+=1
                val=vals[nightCount][0]
            else:
                night=0
        
        
        
        window.blit(pg.font.Font(None,50).render(f"{guy.hp}/20 hp",True,"black"),(1750,0))
        

        #pgp.blit(window,cam,transpsurf,0,0)
        if night:
            window.blit(transpsurf,(0,0))
            if random.randint(1,1000)<=val:
                if random.randint(1,2)==1:
                    xxx=random.randint(guy.Rect.centerx-800,guy.Rect.centerx-400)
                else:
                    xxx=random.randint(guy.Rect.centerx+400,guy.Rect.centerx+800)
                if random.randint(1,2)==1:
                    yyy=random.randint(guy.Rect.centery-800,guy.Rect.centery-400)
                else:
                    yyy=random.randint(guy.Rect.centery+400,guy.Rect.centery+800)
                mobinv=[]
                if random.randint(1,8)<=nightCount:
                    mobinv.append(13)
                elif random.randint(1,12)<=nightCount:
                    mobinv.append(19)
                if random.randint(1,16)<=nightCount:
                    mobinv.append(22)
                elif random.randint(3,24)<=nightCount:
                    mobinv.append(60)
                if random.randint(1,16)<=nightCount:
                    mobinv.append(24)
                elif random.randint(3,24)<=nightCount:
                    mobinv.append(61)
                moblist.append(Mob(pg.Rect(xxx//100*100,yyy//100*100,100,100),mobinv))

        
    else:
        window.fill("black")
        pgp.blit(window,cam,omegafont.render(f"You Survived {nightCount} nights.",True,"white"),omegarect.x,omegarect.y)
        pgp.blit(window,cam,txt2,rect2.x,rect2.y)

    
    if firstloop:
        first=datetime.now()
        min=first.minute
        sec=first.second
        print("All Is Ready",min,sec)
        firstloop=0
    
    pg.display.update()
    clock.tick(60)
pg.quit()