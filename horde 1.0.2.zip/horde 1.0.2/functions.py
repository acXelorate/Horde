from consts import *

def craft(bool,inv:list,ings:list,results:list,droprect:pg.Rect):
    from classes import Item
    invcopy=inv.copy()
    if bool:
        for ing in ings:
            if ing in invcopy:
                index=invcopy.index(ing)
                invcopy[index]=0
            else:
                return inv
        inv=invcopy
        for result in results:
            if 0 in inv:
                index=invcopy.index(0)
                inv[index]=result
            else:
                itemlist.append(Item(copy(droprect),result))
    return inv

def drop(inv:list,slot,droprect:pg.Rect):
    from classes import Item
    if inv[slot]!=0:

        itemlist.append(Item(copy(droprect),inv[slot]))
        inv[slot]=0
    return inv

def conv(v,dl):
    return v % dl

def grow_biome():
    for row,arr in enumerate(biomematrix):
        for col,tile in enumerate(arr):
            quickgrow(row+1,col,tile)
            quickgrow(row-1,col,tile)
            quickgrow(row,col+1,tile)
            quickgrow(row,col-1,tile)

def quickgrow(x,y,tile):
    if tile>0 and random.randint(1,100)<tile:
        try:
            if biomematrix[x][y]==0:
                biomematrix[x][y]=tile-10

        except: pass

""" def get_viewport(x,y):
    x=(x+100)//100
    y=(y+100)//100
    left=x-11
    right=x+11
    top=y-6
    bottom=y+6

    region=[row[left:right] for row in biomematrix[top:bottom]]

    print(region)

    return region,left*100-100,top*100-100 """

def blitRich(txt:str,x,y):

    richlist=[]
    number=""
    for i in txt:
        if i.isdigit():
            number+=i
        else:
            if number:
                richlist.append(number)
                number=""
            richlist.append(i)
    
    if number:
        richlist.append(number)
    for i,char in enumerate(richlist):
        try:
            int(char)
            dig=1
        except:
            dig=0
        if dig:
            img=pg.transform.scale(itemsprites[int(char)],(50,50))
            pgp.blit(window,cam,img,x,y)
            x+=50
        else:
            txt=font.render(char,True,"white")
            pgp.blit(window,cam,txt,x,y)
            x+=txt.get_size()[0]

def convert_to_matrix():
    matrix=[[0 for _ in range(201)] for _ in range(201)]
    for obb in obblist:
        x=obb.Rect.x//100+100
        y=obb.Rect.y//100+100
        matrix[x][y]=1
        
    return matrix

def pitagora(pos1,pos2,dist):
    if sqrt((pos1[0]-pos2[0])**2+(pos1[1]-pos2[1])**2)<dist:
        return True
    return False